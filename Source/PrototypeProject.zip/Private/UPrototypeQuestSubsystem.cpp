// Fill out your copyright notice in the Description page of Project Settings.

#include "UPrototypeQuestSubsystem.h"

void UUPrototypeQuestSubsystem::Initialize(FSubsystemCollectionBase &Collection)
{
	Super::Initialize(Collection);

	UE_LOG(LogTemp, Log, TEXT("QuestSubsystem Initialized"));
}

void UUPrototypeQuestSubsystem::Deinitialize()
{
	Super::Deinitialize();
	QuestStateMap.Empty();
}

void UUPrototypeQuestSubsystem::SetQuestState(FName QuestID, bool bCompleted)
{
	QuestStateMap.Add(QuestID, bCompleted);
	OnQuestUpdated.Broadcast(QuestID);
}

bool UUPrototypeQuestSubsystem::IsQuestCompleted(FName QuestID) const
{
	if(const bool* bState = QuestStateMap.Find(QuestID))
	{
		return *bState;
	}
	return false;
}
