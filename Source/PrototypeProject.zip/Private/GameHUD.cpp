// Fill out your copyright notice in the Description page of Project Settings.


#include "GameHUD.h"
#include "QuestUIWidget.h"
#include "UPrototypeQuestSubsystem.h"

AGameHUD::AGameHUD()
{
    static ConstructorHelpers::FClassFinder<UQuestUIWidget> WidgetBPClass(TEXT("/Game/Blueprints/WBP_QuestUIWidget.WBP_QuestUIWidget_C"));
    if (WidgetBPClass.Succeeded())
    {
         QuestWidgetUI = WidgetBPClass.Class;
    }
}

void AGameHUD::BeginPlay()
{
    Super::BeginPlay();
}

void AGameHUD::CompletedWidget(FName QuestID)
{
    if (QuestWidgetUI)
    {
        QuestWidget = CreateWidget<UQuestUIWidget>(GetWorld(), QuestWidgetUI);
        if (QuestWidget)
        {
            QuestWidget->SetInitialQuestID(QuestID);
            QuestWidget->AddToViewport();

		    FTimerHandle ViewTimer;

		    GetWorld()->GetTimerManager().SetTimer(ViewTimer, [&]()
		    {
			    QuestWidget->RemoveFromParent();
		    }, 4.f, false);
        }
    }
}
