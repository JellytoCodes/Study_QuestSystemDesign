// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "GameHUD.generated.h"

/**
 * 
 */
UCLASS()
class PROTOTYPEPROJECT_API AGameHUD : public AHUD
{
	GENERATED_BODY()

public :
	AGameHUD();

	void CompletedWidget(FName QuestID);

protected :
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, Category = "UI")
	TSubclassOf<class UQuestUIWidget> QuestWidgetUI;

	UQuestUIWidget* QuestWidget;

	
};
